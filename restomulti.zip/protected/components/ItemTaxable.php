<?php
class ItemTaxable
{
	
	public static function compute($data='', $tax='', $mtid='')
	{			
		$tax=$tax+1;		
		
			
		//dump($data);
		return $data;
	}
		
} 
/*end class*/